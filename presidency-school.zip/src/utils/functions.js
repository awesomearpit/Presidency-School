export const nonDigitRemove = str => {
  return str.replace(/[^\d]/g, "");
};
