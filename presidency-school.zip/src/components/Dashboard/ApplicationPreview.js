import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";

class ApplicationPreview extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <>
        <h1 className="text-center">Under Working.......</h1>
      </>
    );
  }
}

export default withRouter(ApplicationPreview);
